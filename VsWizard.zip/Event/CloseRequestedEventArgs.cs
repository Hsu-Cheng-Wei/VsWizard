﻿namespace $safeprojectname$.Event
{
    internal class CloseRequestedEventArgs
    {
        public bool? DialogResult { get; }

        public CloseRequestedEventArgs(bool? dialogResult)
        {
            DialogResult = dialogResult;
        }
    }
}
