﻿using $safeprojectname$.Contract;
using $safeprojectname$.Extensions;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace $safeprojectname$.Infrastructure
{
    internal abstract class BaseCommander : ICommander
    {
        public abstract Guid MenuGroup { get; }

        public abstract int CommandID { get; }

        public abstract void Handler(object sender, EventArgs e);
    }

    internal abstract class BaseCommander<THandler> : BaseCommander where THandler : ICommanderHandler
    {
        protected readonly IServiceProvider _serviceProvider;
        protected CancellationToken _cancellationToken;
        public BaseCommander(IServiceProvider serviceProvider, CancellationToken cancellationToken)
        {
            _serviceProvider = serviceProvider;
            _cancellationToken = cancellationToken;
        }

        public override void Handler(object sender, EventArgs e)
        {
            _ = SendAsync();
        }

        private THandler GetHandler()
        => typeof(THandler).CreateInstance<THandler>(_serviceProvider);


        protected async Task SendAsync()
        {
            var handler = GetHandler();

            await handler.HandlerAsync(_cancellationToken);
        }
    }
}
