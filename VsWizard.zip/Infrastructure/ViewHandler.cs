﻿using $safeprojectname$.Contract;
using Microsoft.VisualStudio.Shell;
using System.Threading;
using Task = System.Threading.Tasks.Task;

namespace $safeprojectname$.Infrastructure
{
    internal abstract class ViewHandler<TModle, TDialog> : ICommanderHandler
        where TModle : class, IModel
        where TDialog : IDialogAsync<TModle>
    {

        protected readonly TDialog _dialog;
        public ViewHandler(TDialog dialog)
        {
            _dialog = dialog;
        }

        protected abstract Task ActionAsync(TModle modle, CancellationToken cancellationToken);

        public async Task HandlerAsync(CancellationToken cancellationToken)
        {
            await ThreadHelper.JoinableTaskFactory.SwitchToMainThreadAsync(cancellationToken);

            var result = await _dialog.GetResponseAsync(cancellationToken);

            if (!result.isOk)
                return;

            await ActionAsync(result.model, cancellationToken);
        }
    }
}
