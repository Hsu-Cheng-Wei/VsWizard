﻿namespace $safeprojectname$
{
    internal class GuidList
    {
        public const string PackagePkg = "cd1addfa-20d1-49f6-a847-1338c92c17e7";

        public const string PackageCmd = "6808601f-72c4-4386-9e83-d5e23839cc69";
    }
}
