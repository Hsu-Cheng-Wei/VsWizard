﻿namespace $safeprojectname$.Contract
{
    internal interface IResponse<TModel> where TModel : IModel
    {
        bool? IsOk { get; set; }

        TModel Response { get; set; }
    }
}
