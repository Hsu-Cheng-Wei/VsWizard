﻿using System.Threading;
using System.Threading.Tasks;

namespace $safeprojectname$.Contract
{
    internal interface ICommanderHandler
    {
        Task HandlerAsync(CancellationToken cancellationToken);
    }
}
