﻿using Microsoft.Extensions.DependencyInjection;
using System;

namespace $safeprojectname$.Contract
{
    internal interface IScope
    {
        IServiceCollection AddService(IServiceCollection services, Type serviceType, Type implementationType);

        IServiceCollection AddService(IServiceCollection services, Type implementationType);
    }

    internal class Singleton : IScope
    {
        public IServiceCollection AddService(IServiceCollection services, Type serviceType, Type implementationType)
        {
            return services.AddSingleton(serviceType, implementationType);
        }

        public IServiceCollection AddService(IServiceCollection services, Type implementationType)
        {
            return services.AddSingleton(implementationType);
        }
    }

    internal class Transient : IScope
    {
        public IServiceCollection AddService(IServiceCollection services, Type serviceType, Type implementationType)
        {
            return services.AddTransient(serviceType, implementationType);
        }

        public IServiceCollection AddService(IServiceCollection services, Type implementationType)
        {
            return services.AddTransient(implementationType);
        }
    }

    internal class Scoped : IScope
    {
        public IServiceCollection AddService(IServiceCollection services, Type serviceType, Type implementationType)
        {
            return services.AddScoped(serviceType, implementationType);
        }

        public IServiceCollection AddService(IServiceCollection services, Type implementationType)
        {
            return services.AddScoped(implementationType);
        }
    }

    internal interface IDependenInjection { }

    internal interface IDependenInjection<TScope> : IDependenInjection where TScope : IScope { }
}
