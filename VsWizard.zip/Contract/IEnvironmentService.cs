﻿using EnvDTE;
using System.Threading;
using System.Threading.Tasks;

namespace $safeprojectname$.Contract
{
    internal interface IEnvironmentService : IEnvironmentAsync, IEnvironment, IDependenInjection<Singleton>
    { }

    internal interface IEnvironmentAsync
    {
        Task<Solution> GetSolutionAsync(CancellationToken cancellationToken);

        Task<ProjectItems> GetCurrentProjectItemsAsync(CancellationToken cancellationToken);

        Task<ProjectItems> FindProjectItemsAsync(string name, CancellationToken cancellationToken);
    }

    internal interface IEnvironment
    {
        Solution GetSolution();

        ProjectItems GetCurrentProjectItems();

        ProjectItems FindProjectItems(string name);
    }
}
