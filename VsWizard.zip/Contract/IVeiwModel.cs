﻿namespace $safeprojectname$.Contract
{
    internal interface IVeiwModel { }

    internal interface IVeiwModel<TModel> : IVeiwModel where TModel : IModel
    {
        TModel Model { get; set; }
    }
}
