﻿using System.Threading;
using System.Threading.Tasks;

namespace $safeprojectname$.Contract
{
    internal interface IDialog<TModel> where TModel : IModel
    {
        (bool isOk, TModel model) GetResponse();
    }

    internal interface IDialogAsync<TModel> where TModel : IModel
    {
        Task<(bool isOk, TModel model)> GetResponseAsync(CancellationToken cancellationToken);
    }
}
