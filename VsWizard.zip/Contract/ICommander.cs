﻿using System;

namespace $safeprojectname$.Contract
{
    internal interface ICommander
    {
        Guid MenuGroup { get; }

        int CommandID { get; }

        void Handler(object sender, EventArgs e);
    }
}
