﻿namespace $safeprojectname$.Contract
{
    internal interface IModel { }
}
