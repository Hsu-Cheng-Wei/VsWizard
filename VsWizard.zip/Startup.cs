﻿using $safeprojectname$.Extensions;
using $safeprojectname$.Infrastructure;
using EnvDTE;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.Shell;
using System;
using System.ComponentModel.Design;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using Task = System.Threading.Tasks.Task;

namespace $safeprojectname$
{
    //[PackageRegistration(UseManagedResourcesOnly = true, AllowsBackgroundLoading = true)]
    //[Guid(GuidList.PackagePkg)]
    //[SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1650:ElementDocumentationMustBeSpelledCorrectly", Justification = "pkgdef, VS and vsixmanifest are valid VS terms")]
    //[ProvideMenuResource("Menus.ctmenu", 1)]
    [PackageRegistration(UseManagedResourcesOnly = true, AllowsBackgroundLoading = true)]
    [InstalledProductRegistration("#110", "#112", "1.0", IconResourceID = 400)]
    [ProvideMenuResource("Menus.ctmenu", 1)]
    [Guid(GuidList.PackagePkg)]
    [SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1650:ElementDocumentationMustBeSpelledCorrectly", Justification = "pkgdef, VS and vsixmanifest are valid VS terms")]
    public sealed class Startup : AsyncPackage
    {
        protected override async Task InitializeAsync(CancellationToken cancellationToken, IProgress<ServiceProgressData> progress)
        {
            await base.InitializeAsync(cancellationToken, progress);

            var service = await CreateServiceAsync(cancellationToken);

            var oleMenuCommandService = await GetServiceAsync(typeof(IMenuCommandService)) as OleMenuCommandService;
            if (oleMenuCommandService != null)
            {
                var commanders = typeof(Startup).Assembly
                    .GetTypes()
                    .Where(t => !t.IsAbstract)
                    .Where(t => typeof(BaseCommander).IsAssignableFrom(t));

                foreach (var commandType in commanders)
                {
                    var command = (BaseCommander)Activator.CreateInstance(commandType, service, this.DisposalToken);
                    var cid = new CommandID(command.MenuGroup, command.CommandID);
                    var menu = new OleMenuCommand(command.Handler, cid);

                    oleMenuCommandService.AddCommand(menu);
                }
            }
        }

        private async Task<IServiceProvider> CreateServiceAsync(CancellationToken cancellationToken)
        {
            await JoinableTaskFactory.SwitchToMainThreadAsync(cancellationToken);

            var _dte = (DTE)await GetServiceAsync(typeof(DTE));

            var service = new ServiceCollection();

            service.AddSingleton((s) => _dte);

            service.AddDependenInjection(GetType().Assembly);

            return service.BuildServiceProvider();
        }
    }
}
