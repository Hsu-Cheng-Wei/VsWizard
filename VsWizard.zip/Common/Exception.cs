﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace $safeprojectname$.Common
{
    public class Exception
    {
        public static void NullableException(object obj, Type type)
        {
            if (obj == null)
            {
                throw new ArgumentNullException($"object {type.Name} can't be Null");
            }
        }

        public static void ShowError(string message)
        {
            MessageBox.Show(
                    message,
                    "錯誤",
                    MessageBoxButtons.OK);

            throw new System.Exception(message);
        }

        public static void AssertInclude<T>(T source, params T[] pattern)
        {
            if (!pattern.Contains(source))
                throw new System.Exception();
        }

        public static void AssertExclude<T>(T source, params T[] pattern)
        {
            if (pattern.Contains(source))
                throw new System.Exception();
        }
    }
}
