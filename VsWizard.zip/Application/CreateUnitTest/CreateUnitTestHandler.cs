﻿using $safeprojectname$.Contract;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace $safeprojectname$.Application.CreateUnitTest
{
    internal sealed class CreateUnitTestHandler : ICommanderHandler
    {
        public Task HandlerAsync(CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
    }
}
