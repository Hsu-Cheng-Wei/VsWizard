﻿using $safeprojectname$.Infrastructure;
using System;
using System.Threading;

namespace $safeprojectname$.Application.CreateUnitTest
{
    internal sealed class CreateUnitTestCommand : BaseCommander<CreateUnitTestHandler>
    {
        public CreateUnitTestCommand(IServiceProvider serviceProvider, CancellationToken cancellationToken) : base(serviceProvider, cancellationToken) { }

        public override Guid MenuGroup
        {
            get => Guid.Parse(GuidList.PackageCmd);
        }

        public override int CommandID
        {
            get => (int)CmdList.CreateUnitTestCmd;
        }
    }
}
