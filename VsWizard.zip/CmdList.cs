﻿namespace $safeprojectname$
{
    internal class CmdList
    {
        public const uint CreateUnitTestCmd = 0x0001;
    }
}
