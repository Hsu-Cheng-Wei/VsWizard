﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace $safeprojectname$.Extensions
{
    internal static class TypeExtensions
    {
        public static T CreateInstance<T>(this Type type, IServiceProvider serviceProvider)
        {
            var paramters = type.GetConstructors().FirstOrDefault()?.GetParameters() ?? new ParameterInfo[] { };

            var parametersImplement = new List<object>();
            foreach (var p in paramters)
            {
                var pType = p.ParameterType;

                var obj = serviceProvider.GetService(pType);

                if (obj == null)
                    throw new Exception($"{nameof(p.Name)} doesn't exist in {nameof(IServiceProvider)}");

                parametersImplement.Add(obj);
            }

            return (T)Activator.CreateInstance(type, parametersImplement.ToArray());
        }
    }
}
