﻿using $safeprojectname$.Contract;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;
using System.Reflection;

namespace $safeprojectname$.Extensions
{
    internal static class IocExtension
    {
        public static IServiceCollection AddDependenInjection(this IServiceCollection services, Assembly asm)
        {
            var dInj = asm.ExportedTypes
                .Where(t => t != typeof(IDependenInjection))
                .Where(t => t != typeof(IDependenInjection<>))
                .Where(t => typeof(IDependenInjection).IsAssignableFrom(t));

            foreach (var serviceType in dInj)
            {
                var dGInj = serviceType.GetInterfaces()
                    .Where(t => t.IsGenericType)
                    .Where(t => typeof(IDependenInjection).IsAssignableFrom(t))
                    .FirstOrDefault();

                if (dGInj == null)
                    continue;

                var scopeTrait = dGInj.GetGenericArguments().FirstOrDefault();

                if (scopeTrait == null)
                    continue;

                var scope = ((IScope)Activator.CreateInstance(scopeTrait));

                if (serviceType.IsInterface)
                {
                    var implementType =
                    asm.ExportedTypes.Where(t => t.IsClass)
                        .Where(t => serviceType.IsAssignableFrom(t)).FirstOrDefault();
                    if (implementType == null)
                        continue;
                    scope.AddService(services, serviceType, implementType);
                }
                else
                    scope.AddService(services, serviceType);
            }

            return services;
        }
    }
}
